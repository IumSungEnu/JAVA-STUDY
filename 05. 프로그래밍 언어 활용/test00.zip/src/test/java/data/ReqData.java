package data;


public interface ReqData<T> extends WithData {
    void userdata(T t);
}
