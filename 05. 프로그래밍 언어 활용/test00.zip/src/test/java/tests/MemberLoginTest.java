package tests;

public class MemberLoginTest {
}
