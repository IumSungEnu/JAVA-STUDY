package commons;

public class CommonLibrary {
    public String toConvert(String str){
        return str.toUpperCase();
    }
}
