package org.koreait.constants;

public enum UserType {  //enum으로 설정
    USER,  //일반회원
    ADMIN  //관리자
}
