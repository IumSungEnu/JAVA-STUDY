package org.koreait.controllers.admins;

public class MainController {
}
